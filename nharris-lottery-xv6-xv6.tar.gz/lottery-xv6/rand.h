#pragma once
#ifndef __RAND_H
 #define __RAND_H



unsigned int rand(void);
void srand(unsigned int seed);

#endif // __RAND_H